/*
* $URL: https://seu10.gdc-dmst01.t-systems.com/svn/MP/src/mp/tags/mp_04_24/doc/javascript/parse_time.js $
*
* $Author: idubashi $
* $Date: 2017-11-20 14:10:27 +0100 (Mon, 20 Nov 2017) $
* $Revision: 12310 $
*/
function get_number(io_String) {
   var l_pos;
   var l_left;
   var l_right;
   if (!io_String) {
      return 0;
   }
   l_pos = io_String.indexOf(":");
   if (l_pos >= 0) {
      l_left = "0" + io_String.substring(0, l_pos);
      l_right = io_String.substring(l_pos + 1, io_String.length);
      l_left = l_left.substr(l_left.length - 2, 2);
      return parseFloat(l_left) * 60 + parseFloat(l_right);
   }

   l_pos = io_String.indexOf(",");
   if (l_pos >= 0) {
      l_left = io_String.substring(0, l_pos);
      l_right = io_String.substring(l_pos + 1, io_String.length);
      io_String = l_left + parseFloat("." + l_right);
   }
   l_pos = io_String.indexOf(".");
   if (l_pos >= 0) {
      l_left = io_String.substring(0, l_pos);
      l_right = io_String.substring(l_pos, io_String.length);
      io_String = (parseFloat(l_left) * 60) + (parseFloat(l_right) * 60);
      return io_String;
   }

   if (isNaN(io_String)) {
      return 0;
   } else {
      return parseFloat(io_String) * 60;
   }
}

function convertToPoint(io_String) {
   var l_pos;
   var l_left;
   var l_right;
   if (!io_String) {
      return 0;
   }
   l_pos = io_String.indexOf("/");
   if (l_pos >= 0) {
      l_left = io_String.substring(0, l_pos);
      l_right = io_String.substring(l_pos + 1, io_String.length) + "0";
      return l_left + l_right.substring(0, 2);
   }
   l_pos = io_String.indexOf(",");
   if (l_pos >= 0) {
      l_left = io_String.substring(0, l_pos);
      l_right = "." + io_String.substring(l_pos + 1, io_String.length);
   }
   l_pos = io_String.indexOf(".");
   if (l_pos >= 0) {
      l_left = io_String.substring(0, l_pos);
      l_right = io_String.substring(l_pos, io_String.length);
   }
   try {
      //        l_right = parseFloat(l_right * 60);
      l_right = parseInt(parseFloat(l_right * 60));
      if (l_right < 10) l_right = "0" + l_right;
   } catch (e) {
      return 0;
   }
   io_String = l_left + l_right;
   return io_String;
}

function makeHour(i_Zahl) {
   var l_hour;
   var l_min;
   var l_hour_c;
   var l_min_c;

   l_hour = parseInt(i_Zahl / 60);
   l_min = parseInt(i_Zahl, 10) - 60 * l_hour;

   if (l_hour < 10) {
      l_hour_c = "0" + l_hour;
   } else {
      l_hour_c = l_hour;
   }

   if (l_min < 10) {
      l_min_c = "0" + l_min;
   } else {
      l_min_c = l_min;
   }
   return (l_hour_c + ":" + l_min_c);
}

function parseTime(i_time_input) {
   rawEntry = i_time_input.value;
   if (rawEntry != "") {
      if ((rawEntry.indexOf(":") == 0) || (rawEntry.indexOf(".") == 0) || (rawEntry.indexOf(",") == 0) || (rawEntry.indexOf("/") == 0)) {
         rawEntry = "0" + rawEntry;
      }
      if ((rawEntry.indexOf(":") < 0) && (rawEntry.length >= 3)) {
         if ((rawEntry.indexOf(",") >= 0) || (rawEntry.indexOf(".") >= 0) || (rawEntry.indexOf("/") >= 0)) {
            rawEntry = convertToPoint(rawEntry);
         }
         var minuten = rawEntry.substr(rawEntry.length - 2, 2);
         var stunden = rawEntry.substr(0, rawEntry.length - 2);
         stunden = "0" + stunden;
         stunden = stunden.substr(stunden.length - 2, 2);
         i_time_input.value = makeHour(get_number(stunden.concat(":").concat(minuten)));
      } else {
         i_time_input.value = makeHour(get_number(rawEntry));
      }
   }
}
