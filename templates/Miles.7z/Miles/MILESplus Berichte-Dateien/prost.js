/*
* $URL: https://seu10.gdc-dmst01.t-systems.com/svn/MP/src/mp/tags/mp_04_24/doc/javascript/prost.js $
*
* $Author: kterekho $
* $Date: 2018-10-31 16:49:44 +0100 (Wed, 31 Oct 2018) $
* $Revision: 13165 $
*/
function Init(){
   if (document.getElementById("delayedDisplay")){
      document.getElementById("delayedDisplay").style.display = "inline";
      document.getElementById("waitDisplay").style.display = "none";
   }
};

function setInactive(obj) {
   obj.value = obj.value + ".";
}

//send Reqest to Server
var g_lang="";
function set_lang(i_sp_id){
   g_lang=i_sp_id;
   req=initXMLHTTPRequest();
   if (req){
      req.onreadystatechange=onReadyState;
      req.open("GET", "prost.set_lang?i_sp_id="+i_sp_id, true);
      req.setRequestHeader("Cache-Control", "no-cache");
      req.send();
   }
}

//create Request
function initXMLHTTPRequest(){
   var xRequest=null;
   if (window.XMLHttpRequest) {
      xRequest = new XMLHttpRequest();
   } else if (window.ActiveXObject) {
      xRequest = new ActiveXObject("Msxml2.XMLHTTP");
   }
   return xRequest;
}

//process the Answer
function onReadyState(){
   var ready=req.readyState;
   if (ready==4){
      if (req.responseText.length > 2){
         window.location.reload(true);
      } else {
         var str = window.location.toString();
         if (str.indexOf("plogin.login") != -1 &&
             str.indexOf("i_message") != -1) {
            window.location = str.replace(/i_last_sp=.../, "i_last_sp=" + g_lang);
         } else {
            window.location = "plogin.login?i_last_sp=" + g_lang;
         }
      }
   }
}